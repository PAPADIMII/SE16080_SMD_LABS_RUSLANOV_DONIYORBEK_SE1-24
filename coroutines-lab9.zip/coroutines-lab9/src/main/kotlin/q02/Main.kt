package q02

import kotlinx.coroutines.*

fun main() {
    println("--- with delay ---")
    runBlocking {
        launch { drinkWithDelay("espresso", 300) }
        launch { drinkWithDelay("tea", 100) }
        launch { drinkWithDelay("latte", 200) }
    }
    println("--- with Thread.sleep ---")
    runBlocking {
        launch { drinkWithSleep("espresso", 300) }
        launch { drinkWithSleep("tea", 100) }
        launch { drinkWithSleep("latte", 200) }
    }
}

suspend fun drinkWithDelay(name: String, ms: Long) {
    println("$name start")
    delay(ms)
    println("$name end")
}

suspend fun drinkWithSleep(name: String, ms: Long) {
    println("$name start")
    Thread.sleep(ms)
    println("$name end")
}
