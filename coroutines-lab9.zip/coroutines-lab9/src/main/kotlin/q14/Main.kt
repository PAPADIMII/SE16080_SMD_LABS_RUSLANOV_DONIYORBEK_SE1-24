package q14

import kotlinx.coroutines.*

fun main() = runBlocking {
    // launch: no way to get 6 * 7 out
    val job: Job = launch { 6 * 7 }
    job.join()
    println("launch gave a Job only, no value to read")

    // async: Deferred<Int> carries the result
    val deferred: Deferred<Int> = async { 6 * 7 }
    println(deferred.await())
}
