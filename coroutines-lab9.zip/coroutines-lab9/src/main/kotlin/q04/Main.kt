package q04

import kotlinx.coroutines.*

suspend fun loadUser(): String {
    delay(100)
    return "Ada"
}

// BROKEN version (does not compile):
// fun showUser() {
//     val user = loadUser()   // error: Suspend function 'loadUser' should be called only from a coroutine or another suspend function.
//     println(user)
// }

// Fix 1: bridge with runBlocking (blocks the calling thread)
fun showUserBlocking() {
    val user = runBlocking { loadUser() }
    println("Fix 1 (runBlocking): $user")
}

// Fix 2: make the caller suspend too
suspend fun showUserSuspend() {
    val user = loadUser()
    println("Fix 2 (suspend): $user")
}

fun main() = runBlocking {
    showUserBlocking()
    showUserSuspend()
}
