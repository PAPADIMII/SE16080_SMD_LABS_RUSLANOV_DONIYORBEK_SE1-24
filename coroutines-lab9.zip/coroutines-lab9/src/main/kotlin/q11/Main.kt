package q11

import kotlinx.coroutines.*

fun CoroutineScope.launchCounter(name: String, limit: Int): Job = launch {
    for (i in 1..limit) {
        delay(100)
        println("$name: $i")
    }
}

fun main() = runBlocking {
    coroutineScope {
        launchCounter("A", 3)
        launchCounter("B", 2)
        println("launched")
    }
    println("all counters done")
}
