package q13

import kotlinx.coroutines.*

fun main() {
    val fromRunBlocking = runBlocking {
        val job = launch { delay(50) }
        println("launch returned a Job, isActive=${job.isActive}")

        val deferred = async { delay(50); 10 }
        println("async returned a Deferred, await() = ${deferred.await()}")

        val fromScope = coroutineScope { delay(50); "coroutineScope result" }
        println(fromScope)

        val fromContext = withContext(Dispatchers.Default) { "withContext result" }
        println(fromContext)

        "runBlocking result"
    }
    println(fromRunBlocking)
}
