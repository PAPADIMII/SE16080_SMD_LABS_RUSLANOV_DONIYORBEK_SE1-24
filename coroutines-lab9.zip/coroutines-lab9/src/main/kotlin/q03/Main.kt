package q03

import kotlinx.coroutines.*

suspend fun loadUser() {
    println("Step 1: load user")
    delay(200)
    checkPassword()
}

suspend fun checkPassword() {
    println("Step 2: check password")
    delay(200)
    openProfile()
}

suspend fun openProfile() {
    println("Step 3: open profile")
    delay(200)
    println("Step 3 finished")
}

suspend fun main() {
    loadUser()
    println("Login flow finished")
}
