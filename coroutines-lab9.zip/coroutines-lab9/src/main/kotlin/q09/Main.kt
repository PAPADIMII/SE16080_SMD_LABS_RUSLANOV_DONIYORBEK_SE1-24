package q09

import kotlinx.coroutines.*

fun main() = runBlocking {
    val parent = launch {
        repeat(2) { index ->
            val n = index + 1
            launch {
                try {
                    println("request $n running")
                    delay(1000)
                    println("request $n finished")   // never printed
                } finally {
                    println("request $n cleanup")
                }
            }
        }
    }
    delay(100)
    parent.cancelAndJoin()
    println("end")
}
