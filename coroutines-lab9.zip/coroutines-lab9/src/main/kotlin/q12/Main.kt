package q12

import kotlinx.coroutines.*

// Returns at once: the greeter lives in the caller's scope
fun CoroutineScope.startGreeter(name: String): Job = launch {
    delay(300)
    println("Hello, $name (background)")
}

// Waits: returns only when every greeting is printed
suspend fun greetAll(names: List<String>) = coroutineScope {
    for (name in names) {
        launch {
            delay(100)
            println("Hello, $name")
        }
    }
}

fun main() = runBlocking {
    startGreeter("Ada")
    println("after startGreeter (returned at once)")
    greetAll(listOf("Linus", "Grace"))
    println("after greetAll (everybody greeted)")
}
