package q05

import kotlinx.coroutines.*

suspend fun currentThreadName(): String {
    delay(10)
    return Thread.currentThread().name
}

fun main() = runBlocking {
    println("Before call: ${Thread.currentThread().name}")
    val name = currentThreadName()
    println("Returned:    $name")
}
