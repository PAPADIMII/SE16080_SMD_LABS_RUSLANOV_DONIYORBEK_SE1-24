package extra1

import kotlinx.coroutines.*
import kotlin.system.measureTimeMillis

fun round100(ms: Long) = ((ms + 50) / 100) * 100

fun main() = runBlocking {
    val withDelay = measureTimeMillis {
        coroutineScope {
            repeat(3) { launch { delay(300) } }
        }
    }
    val withSleep = measureTimeMillis {
        coroutineScope {
            repeat(3) { launch { Thread.sleep(300) } }
        }
    }
    println("delay:        ${round100(withDelay)} ms")
    println("Thread.sleep: ${round100(withSleep)} ms")
}
