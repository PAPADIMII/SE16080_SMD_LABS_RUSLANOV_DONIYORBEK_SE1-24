# Laboratory 9: Coroutines introduction

## Question 1. First coroutine

```

Order accepted
Coffee ready

```

`launch` only schedules the coroutine. The main body does not suspend, so it keeps running on the single thread and prints "Order accepted". The coroutine starts only when main suspends or ends, then waits one second.

## Question 2. Three baristas

With `delay`:

```

espresso start
tea start
latte start
tea end
latte end
espresso end
```
With `Thread.sleep`:
```
espresso start
espresso end
tea start
tea end
latte start
latte end

```

`delay` suspends the coroutine and frees the thread for the other coroutines; `Thread.sleep` blocks the whole thread, so nobody else can run until it wakes up.

## Question 3. Chain of suspend functions

```

Step 1: load user
Step 2: check password
Step 3: open profile
Step 3 finished
Login flow finished

```

Suspending pauses only the current coroutine; the code after a call still runs after the callee returns, so the order of lines stays sequential.

## Question 4. Calling suspend from normal code

Compile error:

```

Suspend function 'loadUser' should be called only from a coroutine or another suspend function.
```
Fix 1: `runBlocking { loadUser() }`. Fix 2: make the caller `suspend` (or call it from a `launch`).
Output:
```
Fix 1 (runBlocking): Ada
Fix 2 (suspend): Ada

```

`runBlocking` is never used on the Android UI thread: it blocks the thread until done, so the screen freezes and can trigger an ANR.

## Question 5. Suspend is not a thread

```

Before call: main
Returned:    main

```

Same thread before and after, so the belief is false: `suspend` does not move work to another thread. The hidden parameter added by the compiler is a `Continuation`.

## Question 6. Ten downloads, one thread

```

download 1 started on main
download 2 started on main
...
download 10 started on main
download 1 finished
download 2 finished
...
download 10 finished

```

All ten start before any finishes. This is concurrency, not parallelism: tasks overlap in time by taking turns on one thread; nothing runs at the same instant.

## Question 7. Order of launch

Prediction and real output:

```

1
4
2
5
3

```

`launch` only queues the coroutine. Main continues (prints 4) until `delay(50)` suspends it; only then does the coroutine run and print 2.

## Question 8. Parent waits for child

```

parent body done
child done
report completed

```

Rule of structured concurrency: a parent coroutine is complete only after all its children are complete, so `join()` on the parent returns after the child.

## Question 9. Screen closed, requests cancelled

```

request 1 running
request 2 running
request 1 cleanup
request 2 cleanup
end

```

Cancelling a parent cancels all its children (cancellation propagates down the tree). `delay` throws `CancellationException`, so `finally` runs and the cleanup is printed.

## Question 10. Profile ready

```

settings loaded
avatar loaded
Profile ready
end of main
late coroutine

```

`coroutineScope` suspends until all its children finish, so "Profile ready" comes after both loads. A `launch` after it is only queued; main prints "end of main" first and `runBlocking` waits for it at the very end.

## Question 11. Reusable counter

```

launched
A: 1
B: 1
A: 2
B: 2
A: 3
all counters done

```

(A and B at the same 100 ms tick can swap places.) The extension on `CoroutineScope` is needed because `launch` is itself an extension of `CoroutineScope`: the receiver provides the scope that the new coroutine belongs to, so the caller controls its lifetime and cancellation.

## Question 12. Returns at once or waits

```

after startGreeter (returned at once)
Hello, Linus
Hello, Grace
after greetAll (everybody greeted)
Hello, Ada (background)

```

`startGreeter` returns at once (the line prints before any greeting). `greetAll` waits: its line prints only after both greetings.

## Question 13. Five builders

```

launch returned a Job, isActive=true
async returned a Deferred, await() = 10
coroutineScope result
withContext result
runBlocking result

```

Cheat sheet:

| Builder | Returns | Blocks the thread? | Waits for children? |
|---|---|---|---|
| `launch` | `Job` | No | No (it is a child of the scope; the scope waits for it) |
| `async` | `Deferred<T>` | No | No (same; the result comes with `await()`) |
| `runBlocking` | `T` (lambda result) | Yes | Yes |
| `coroutineScope` | `T` (lambda result) | No, it suspends | Yes |
| `withContext` | `T` (lambda result) | No, it suspends | Yes |

## Question 14. Job or Deferred

```

launch gave a Job only, no value to read
42

```

`Job` is a handle for lifecycle (join, cancel, isActive) and carries no result. `Deferred<T>` is a `Job` that also holds a result of type `T`, read with `await()`.

## Question 15. Three exports in a scope

```

Start
Y
Z
X
All done

```

---

## Extra 1. Delay or sleep: measure it

```

delay:        300 ms
Thread.sleep: 900 ms

```

(Rounded to hundreds.) With `delay` the three waits overlap because the thread is free during each wait; with `Thread.sleep` the thread is blocked, so the waits run one after another (3 x 300 ms).

## Extra 2. Three levels of coroutines

```

child 1 done
child 2 done
grandchild done
scope done
```

Tree:
```

coroutineScope
 |- child 1
 |   '- grandchild (200 ms)
 '- child 2 (100 ms)
```
"scope done" is last because the scope waits for all descendants; the grandchild (200 ms) is the slowest.

---

## Suspending vs blocking (own explanation)
```
Blocking: the thread itself is stuck. It can do nothing else
until the call returns, so everything on that thread waits.
(Thread.sleep, runBlocking, a blocking network read.)

Suspending: only the coroutine pauses. It saves its state in a
continuation and gives the thread back. The thread runs other
coroutines meanwhile, and when the wait is over the coroutine
resumes where it stopped. (delay, await, join.)

One thread can run thousands of suspended coroutines, but one
blocked thread runs nothing else.
```
